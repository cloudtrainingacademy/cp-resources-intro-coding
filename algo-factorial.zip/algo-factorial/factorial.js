function factorial(num) {
  return 0;
}

module.exports = factorial;
